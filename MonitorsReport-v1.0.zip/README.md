# MonitorsReport


## Overview ##
Mantis plugin: report shows users monitoring issues


## Screenshots ##
![alt text](Screenshots/Monnitor.png)


## Info ##
- Requires MantisBT >2.0.0
- Multi language support


## Download ##
[Current version 1.0](https://github.com/AnatolyKabakov1983/DownloadFiles/releases/download/1.0.0/DownloadFiles-v1.0.0.zip)



## Installation ##
Copy the "`MonitorsReport`" folder in your plugin directory and open the plugin management page in your Mantis installation.
Click "Install" to complete the installation.


## Configuration ##
Nothing to configure.


## License ##
Released under the terms of the GNU General Public License v3 (GPLv3).


## Support ##
 * Any feedback is greatly appreciated!
